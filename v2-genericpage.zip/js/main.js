$(function(){
  $('.circlestat').circliful();
});